package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver {
    private int lastUsbCount = -1;

    @Override
    public void update(SystemMonitor monitor) {
        int currentUsbCount = monitor.getLastSystemState().getUsbDevices();

        if (lastUsbCount != -1 && currentUsbCount != lastUsbCount) {
            System.out.println(String.format("> USB devices count changed: %d -> %d", lastUsbCount, currentUsbCount));
        }

        lastUsbCount = currentUsbCount;
    }
}